name = input("Ingrese su nombre completo:")
age = input ("Ingrese su edad")
city = input ("Ingrese la ciudad donde vive")
email = input ("Ingrese su direccion de correo electronico")
adress = input("Ingrese la direccion donde vive actualmente")
phone = input("Ingrese su telefono")

print ("Su nombre es:" , name)
print ("Su edad es:" , age)
print ("Su ciudad es:" , city)
print ("Su Correo electronico es:" , email)
print ("Su Direccion actual es:" , adress)
print ("Su Telefono es:" , phone)



