num1 = 4.5
# esto es el casting de variables
num2 = int(4.5)
number = "3"
print(num2)

number1 = int("3")

print(number1)
print (type(number1))


name = input("Ingrese su nombre:")

print (name)