print ("Hello World !")

# ASi podemos imprimir el contendio de una variable, usando la funcion Print
name = "Pepito" # esto es un string
salary = 1160000 #esto es un entero o integer
note = 4.5 # esto es un float
isOn = True # esto es un boolean
b=b"Pepito" # esto es un byte


# para conocer el tipo de dato usamos la funcion type ()
print (type (name)) 
print (type (salary)) 
print (type (note)) 
print (type (isOn))

fruits= ["banana", "mango", "Sandia"] # esto es una lista
names= ("maria","luis","Juan") # esto es una tupla
cars= ("suv"; "Mazda" , "sedan" , "KiaRio") # esto es un diccionario
ages= {29, 19, 33} # esto es un set


# Esto es un comentario en Python

